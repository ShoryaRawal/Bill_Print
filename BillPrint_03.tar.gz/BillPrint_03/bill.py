import subprocess as sp 
import pandas

def create(Name) :
    File = open(Name + ".py", "x")
    File.write("import pandas \n")
    File.close()

def flush(Name) :
    File = open(Name + ".py", "w")
    File.write("import pandas \n")
    File.close()

def write(Name) :
    name = input("Product Name: ")
    price = input("Product Price(Single): ")
    quantity = input("Product Quantity: ")

    total = int(price) * int(quantity)
    strTotal = str(total)

    item = "\n" + name + " = {'Name': '" + name + "', 'Price' : '" + price +"', 'Quantity' : '" + quantity + "', 'Subtotal' : '" + strTotal +"'}"
    item_ds = "\n" + name + "_ds = pandas.Series(" + name + ")"
    end = "\n" + "print(" + name + "_ds)"
    string = item + item_ds + end

    File = open(Name + ".py", "a")
    File.write(string)
    File.close()

while True :
    cmd = input("_>")
    if cmd == "create" :
        Name = input("File Name: ")
        create(Name)

    if cmd == "flush" :
        Name = input("File Name: ")
        flush(Name)

    if cmd == "write" :
        Name = input("File Name: ")
        write(Name)