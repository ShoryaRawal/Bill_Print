import pandas
import subprocess
from argparse import ArgumentParser, ArgumentTypeError

def one() :
    item1 = str(input("Item name: "))
    item1_price = int(input("Price: "))
    item1_quantity = int(input("quantity: "))

    item1_subtotal = item1_price * item1_quantity
    total = item1_subtotal

    List = {"Name":[item1], "Price":[item1_price], "Quantity":[item1_quantity], "Subtotal":[item1_subtotal]}
    df = pandas.DataFrame(List)
    print("\n")
    print(df)

    Tax = open("tax.txt", "r")
    tax = Tax.read()
    Tax.close()

    final_total = int(total) + int(tax)

    List2 = {"Final Total":final_total, "Tax":tax, "Total":total, "Total Items":1}
    ds = pandas.Series(List2)
    print("\n")
    print(ds)

    File = open("sales/sales.txt", "a")
    File.write("\n" + str(ds))
    File.close

def two() :
    item1 = input("First Item: ")
    item1_price = input("Price(single): ")
    item1_quantity = input("Quantity: ")

    print("\n")

    item2 = input("Second Item: ")
    item2_price = input("Price: ")
    item2_quantity = input("quantity: ")

    print("\n")

    item1_subtotal = int(item1_price) * int(item1_quantity)
    item2_subtotal = int(item2_price) * int(item2_quantity)

    total = item1_subtotal + item2_subtotal

    List = {"Name":[item1, item2], "Price":[item1_price, item2_price], "Quantity":[item1_quantity, item2_quantity], "Subtotal":[item1_subtotal, item2_subtotal]}
    df = pandas.DataFrame(List)
    print("\n")
    print(df)

    Tax = open("tax.txt", "r")
    tax = Tax.read()
    Tax.close()

    final_total = int(total) + int(tax)

    List2 = {"Final Total":final_total, "Tax":tax, "Total":total, "Total Items":2}
    ds = pandas.Series(List2)
    print("\n")
    print(ds)

    File = open("sales/sales.txt", "a")
    File.write("\n" + str(ds))
    File.close

def three() :
    item1 = input("First item: ")
    item1_price = input("Price: ")
    item1_quantity = input("quantity: ")
    print("\n")

    item2 = input("Second item: ")
    item2_price = input("Price: ")
    item2_quantity = input("Quantity: ")

    print("\n")

    item3 = input("Third name:")
    item3_price = input("Price: ")
    item3_quantity = input("Quantity: ")

    print("\n")

    item1_subtotal = int(item1_price) * int(item1_quantity)
    item2_subtotal = int(item2_price) * int(item2_quantity)
    item3_subtotal = int(item3_price) * int(item3_quantity)

    total = item1_subtotal + item2_subtotal + item3_subtotal

    List = {"Name":[item1, item2, item3], "Price":[item1_price, item2_price, item3_price], "Quantity":[item1_quantity, item2_quantity, item3_quantity], "subtotal":[item1_subtotal, item2_subtotal, item3_subtotal]}
    df = pandas.DataFrame(List)
    print("\n")
    print(df)

    Tax = open("tax.txt", "r")
    tax = Tax.read()
    Tax.close()

    final_total = int(total) + int(tax)

    List2 = {"Final Total":final_total, "Tax":tax, "Total":total, "Total Items":3}
    ds = pandas.Series(List2)
    print("\n")
    print(ds)

    File = open("sales/sales.txt", "a")
    File.write("\n" + str(ds))
    File.close

def four() :
    item1 = input("First Item: ")
    item1_price = input("Price: ")
    item1_quantity = input("Quantity: ")

    print("\n")

    item2 = input("Second item: ")
    item2_price = input("Price: ")
    item2_quantity = input("Quantity: ")

    print("\n")

    item3 = input("Third item: ")
    item3_price = input("Price: ")
    item3_quantity = input("Quantity: ")

    print("\n")

    item4 = input("Fourth Item: ")
    item4_price = input("Price: ")
    item4_quantity = input("Quantity: ")

    item1_subtotal = int(item1_price) * int(item1_quantity)
    item2_subtotal = int(item2_price) * int(item2_quantity)
    item3_subtotal = int(item3_price) * int(item3_quantity)
    item4_subtotal = int(item4_price) * int(item4_quantity)

    total = item1_subtotal + item2_subtotal + item3_subtotal + item4_subtotal

    List = {"Name":[item1, item2, item3, item4], "Price":[item1_price, item2_price, item3_price, item4_price],
            "Quantity":[item1_quantity, item2_quantity, item3_quantity, item4_quantity], "subtotal":[item1_subtotal, item2_subtotal, item3_subtotal, item4_subtotal]}

    df = pandas.DataFrame(List)
    print("\n")
    print(df)

    Tax = open("tax.txt", "r")
    tax = Tax.read()
    Tax.close()

    final_total = int(total) + int(tax)

    List2 = {"Final Total":final_total, "Tax":tax, "Total":total, "Total Items":4}
    ds = pandas.Series(List2)
    print("\n")
    print(ds)

    File = open("sales/sales.txt", "a")
    File.write("\n" + str(ds))
    File.close

def five() :
    item1 = input("First Item: ")
    item1_price = input("Price: ")
    item1_quantity = input("Quantity: ")

    print("\n")

    item2 = input("Second Item: ")
    item2_price = input("Price: ")
    item2_quantity = input("Qunatity: ")

    print("\n")

    item3 = input("Third Item: ")
    item3_price = input("Price: ")
    item3_quantity = input("Quantity: ")

    print("\n")

    item4 = input("Fourth Item: ")
    item4_price = input("Price: ")
    item4_quantity = input("Quantity: ")

    print("\n")

    item5 = input("Fifth Item: ")
    item5_price = input("Price: ")
    item5_quantity = input("Quantity: ")

    item1_subtotal = int(item1_price) * int(item1_quantity)
    item2_subtotal = int(item2_price) * int(item2_quantity)
    item3_subtotal = int(item3_price) * int(item3_quantity)
    item4_subtotal = int(item4_price) * int(item4_quantity)
    item5_subtotal = int(item5_price) * int(item5_quantity)

    total = item1_subtotal + item2_subtotal + item3_subtotal + item4_subtotal + item5_subtotal
    List = {"Name":[item1, item2, item3, item4, item5],
            "Price":[item1_price, item2_price, item3_price, item4_price, item5_price],
            "Quantity":[item1_quantity, item2_quantity, item3_quantity, item4_quantity, item5_quantity],
            "Subtotal":[item1_subtotal, item2_subtotal, item3_subtotal, item4_subtotal, item5_subtotal]}
    df = pandas.DataFrame(List)
    print("\n")
    print(df)

    Tax = open("tax.txt", "r")
    tax = Tax.read()
    Tax.close()

    final_total = int(total) + int(tax)

    List2 = {"Final Total":final_total, "Tax":tax, "Total":total, "Total Items":5}
    ds = pandas.Series(List2)
    print("\n")
    print(ds)

    File = open("sales/sales.txt", "a")
    File.write("\n" + str(ds))
    File.close

def six() :
    item1 = input("First Item: ")
    item1_price = input("Price: ")
    item1_quantity = input("Quantity: ")

    print("\n")

    item2 = input("Second Item: ")
    item2_price = input("Price: ")
    item2_quantity = input("Qunatity: ")

    print("\n")

    item3 = input("Third Item: ")
    item3_price = input("Price: ")
    item3_quantity = input("Quantity: ")

    print("\n")

    item4 = input("Fourth Item: ")
    item4_price = input("Price: ")
    item4_quantity = input("Quantity: ")

    print("\n")

    item5 = input("Fifth Item: ")
    item5_price = input("Price: ")
    item5_quantity = input("Quantity: ")

    print("\n")

    item6 = input("Sixth Item: ")
    item6_price = input("Price: ")
    item6_quantity = input("Quantity: ")

    item1_subtotal = int(item1_price) * int(item1_quantity)
    item2_subtotal = int(item2_price) * int(item2_quantity)
    item3_subtotal = int(item3_price) * int(item3_quantity)
    item4_subtotal = int(item4_price) * int(item4_quantity)
    item5_subtotal = int(item5_price) * int(item5_quantity)
    item6_subtotal = int(item6_price) * int(item6_quantity)

    total = item1_subtotal + item2_subtotal + item3_subtotal + item4_subtotal + item5_subtotal + item6_subtotal
    List = {"Name":[item1, item2, item3, item4, item5, item6],
            "Price":[item1_price, item2_price, item3_price, item4_price, item5_price, item6_price],
            "Quantity":[item1_quantity, item2_quantity, item3_quantity, item4_quantity, item5_quantity, item6_quantity],
            "Subtotal":[item1_subtotal, item2_subtotal, item3_subtotal, item4_subtotal, item5_subtotal, item6_subtotal]}
    df = pandas.DataFrame(List)
    print("\n")
    print(df)

    Tax = open("tax.txt", "r")
    tax = Tax.read()
    Tax.close()

    final_total = int(total) + int(tax)

    List2 = {"Final Total":final_total, "Tax":tax, "Total":total, "Total Items":6}
    ds = pandas.Series(List2)
    print("\n")
    print(ds)

    File = open("sales/sales.txt", "a")
    File.write("\n" + str(ds))
    File.close

def seven() :
    item1 = input("First Item: ")
    item1_price = input("Price: ")
    item1_quantity = input("Quantity: ")

    print("\n")

    item2 = input("Second Item: ")
    item2_price = input("Price: ")
    item2_quantity = input("Qunatity: ")

    print("\n")

    item3 = input("Third Item: ")
    item3_price = input("Price: ")
    item3_quantity = input("Quantity: ")

    print("\n")

    item4 = input("Fourth Item: ")
    item4_price = input("Price: ")
    item4_quantity = input("Quantity: ")

    print("\n")

    item5 = input("Fifth Item: ")
    item5_price = input("Price: ")
    item5_quantity = input("Quantity: ")

    print("\n")

    item6 = input("Sixth Item: ")
    item6_price = input("Price: ")
    item6_quantity = input("Quantity: ")

    print("\n")

    item7 = input("Seventh Item: ")
    item7_price = input("Price: ")
    item7_quantity = input("Quantity: ")

    item1_subtotal = int(item1_price) * int(item1_quantity)
    item2_subtotal = int(item2_price) * int(item2_quantity)
    item3_subtotal = int(item3_price) * int(item3_quantity)
    item4_subtotal = int(item4_price) * int(item4_quantity)
    item5_subtotal = int(item5_price) * int(item5_quantity)
    item6_subtotal = int(item6_price) * int(item6_quantity)
    item7_subtotal = int(item7_price) * int(item7_quantity)

    total = item1_subtotal + item2_subtotal + item3_subtotal + item4_subtotal + item5_subtotal + item6_subtotal + item7_subtotal
    List = {"Name":[item1, item2, item3, item4, item5, item6, item7],
            "Price":[item1_price, item2_price, item3_price, item4_price, item5_price, item6_price, item7_price],
            "Quantity":[item1_quantity, item2_quantity, item3_quantity, item4_quantity, item5_quantity, item6_quantity, item7_quantity],
            "Subtotal":[item1_subtotal, item2_subtotal, item3_subtotal, item4_subtotal, item5_subtotal, item6_subtotal, item7_subtotal]}
    df = pandas.DataFrame(List)
    print("\n")
    print(df)

    Tax = open("tax.txt", "r")
    tax = Tax.read()
    Tax.close()

    final_total = int(total) + int(tax)

    List2 = {"Final Total":final_total, "Tax":tax, "Total":total, "Total Items":7}
    ds = pandas.Series(List2)
    print("\n")
    print(ds)

    File = open("sales/sales.txt", "a")
    File.write("\n" + str(ds))
    File.close

def eight() :
    item1 = input("First Item: ")
    item1_price = input("Price: ")
    item1_quantity = input("Quantity: ")

    print("\n")

    item2 = input("Second Item: ")
    item2_price = input("Price: ")
    item2_quantity = input("Qunatity: ")

    print("\n")

    item3 = input("Third Item: ")
    item3_price = input("Price: ")
    item3_quantity = input("Quantity: ")

    print("\n")

    item4 = input("Fourth Item: ")
    item4_price = input("Price: ")
    item4_quantity = input("Quantity: ")

    print("\n")

    item5 = input("Fifth Item: ")
    item5_price = input("Price: ")
    item5_quantity = input("Quantity: ")

    print("\n")

    item6 = input("Sixth Item: ")
    item6_price = input("Price: ")
    item6_quantity = input("Quantity: ")

    print("\n")

    item7 = input("Seventh Item: ")
    item7_price = input("Price: ")
    item7_quantity = input("Quantity: ")

    print("\n")
    item8 = input("Eirght Item: ")
    item8_price = input("Price: ")
    item8_quantity = input("Quantity: ")

    item1_subtotal = int(item1_price) * int(item1_quantity)
    item2_subtotal = int(item2_price) * int(item2_quantity)
    item3_subtotal = int(item3_price) * int(item3_quantity)
    item4_subtotal = int(item4_price) * int(item4_quantity)
    item5_subtotal = int(item5_price) * int(item5_quantity)
    item6_subtotal = int(item6_price) * int(item6_quantity)
    item7_subtotal = int(item7_price) * int(item7_quantity)
    item8_subtotal = int(item8_price) * int(item8_quantity)

    total = item1_subtotal + item2_subtotal + item3_subtotal + item4_subtotal + item5_subtotal + item6_subtotal + item7_subtotal + item8_subtotal
    List = {"Name":[item1, item2, item3, item4, item5, item6, item7, item8],
            "Price":[item1_price, item2_price, item3_price, item4_price, item5_price, item6_price, item7_price, item8_price],
            "Quantity":[item1_quantity, item2_quantity, item3_quantity, item4_quantity, item5_quantity, item6_quantity, item7_quantity, item8_quantity],
            "Subtotal":[item1_subtotal, item2_subtotal, item3_subtotal, item4_subtotal, item5_subtotal, item6_subtotal, item7_subtotal, item8_subtotal]}
    df = pandas.DataFrame(List)
    print("\n")
    print(df)

    Tax = open("tax.txt", "r")
    tax = Tax.read()
    Tax.close()

    final_total = int(total) + int(tax)

    List2 = {"Final Total":final_total, "Tax":tax, "Total":total, "Total Items":8}
    ds = pandas.Series(List2)
    print("\n")
    print(ds)

    File = open("sales/sales.txt", "a")
    File.write("\n" + str(ds))
    File.close

def nine() :
    item1 = input("First Item: ")
    item1_price = input("Price: ")
    item1_quantity = input("Quantity: ")

    print("\n")

    item2 = input("Second Item: ")
    item2_price = input("Price: ")
    item2_quantity = input("Qunatity: ")

    print("\n")

    item3 = input("Third Item: ")
    item3_price = input("Price: ")
    item3_quantity = input("Quantity: ")

    print("\n")

    item4 = input("Fourth Item: ")
    item4_price = input("Price: ")
    item4_quantity = input("Quantity: ")

    print("\n")

    item5 = input("Fifth Item: ")
    item5_price = input("Price: ")
    item5_quantity = input("Quantity: ")

    print("\n")

    item6 = input("Sixth Item: ")
    item6_price = input("Price: ")
    item6_quantity = input("Quantity: ")

    print("\n")

    item7 = input("Seventh Item: ")
    item7_price = input("Price: ")
    item7_quantity = input("Quantity: ")

    print("\n")
    item8 = input("Eirght Item: ")
    item8_price = input("Price: ")
    item8_quantity = input("Quantity: ")

    print("\n")

    item9 = input("Ninth Item: ")
    item9_price = input("Price: ")
    item9_quantity = input("Qantity: ")

    item1_subtotal = int(item1_price) * int(item1_quantity)
    item2_subtotal = int(item2_price) * int(item2_quantity)
    item3_subtotal = int(item3_price) * int(item3_quantity)
    item4_subtotal = int(item4_price) * int(item4_quantity)
    item5_subtotal = int(item5_price) * int(item5_quantity)
    item6_subtotal = int(item6_price) * int(item6_quantity)
    item7_subtotal = int(item7_price) * int(item7_quantity)
    item8_subtotal = int(item8_price) * int(item8_quantity)
    item9_subtotal = int(item9_price) * int(item9_quantity)

    total = item1_subtotal + item2_subtotal + item3_subtotal + item4_subtotal + item5_subtotal + item6_subtotal + item7_subtotal + item8_subtotal + item9_subtotal
    List = {"Name":[item1, item2, item3, item4, item5, item6, item7, item8, item9],
            "Price":[item1_price, item2_price, item3_price, item4_price, item5_price, item6_price, item7_price, item8_price, item9_price],
            "Quantity":[item1_quantity, item2_quantity, item3_quantity, item4_quantity, item5_quantity, item6_quantity, item7_quantity, item8_quantity, item9_quantity],
            "Subtotal":[item1_subtotal, item2_subtotal, item3_subtotal, item4_subtotal, item5_subtotal, item6_subtotal, item7_subtotal, item8_subtotal, item9_subtotal]}
    df = pandas.DataFrame(List)
    print("\n")
    print(df)

    Tax = open("tax.txt", "r")
    tax = Tax.read()
    Tax.close()

    final_total = int(total) + int(tax)

    List2 = {"Final Total":final_total, "Tax":tax, "Total":total, "Total Items":9}
    ds = pandas.Series(List2)
    print("\n")
    print(ds)

    File = open("sales/sales.txt", "a")
    File.write("\n" + str(ds))
    File.close

def ten() :
    item1 = input("First Item: ")
    item1_price = input("Price: ")
    item1_quantity = input("Quantity: ")

    print("\n")

    item2 = input("Second Item: ")
    item2_price = input("Price: ")
    item2_quantity = input("Qunatity: ")

    print("\n")

    item3 = input("Third Item: ")
    item3_price = input("Price: ")
    item3_quantity = input("Quantity: ")

    print("\n")

    item4 = input("Fourth Item: ")
    item4_price = input("Price: ")
    item4_quantity = input("Quantity: ")

    print("\n")

    item5 = input("Fifth Item: ")
    item5_price = input("Price: ")
    item5_quantity = input("Quantity: ")

    print("\n")

    item6 = input("Sixth Item: ")
    item6_price = input("Price: ")
    item6_quantity = input("Quantity: ")

    print("\n")

    item7 = input("Seventh Item: ")
    item7_price = input("Price: ")
    item7_quantity = input("Quantity: ")

    print("\n")

    item8 = input("Eirght Item: ")
    item8_price = input("Price: ")
    item8_quantity = input("Quantity: ")

    print("\n")

    item9 = input("Ninth Item: ")
    item9_price = input("Price: ")
    item9_quantity =  input("Quantity: ")

    print("\n")

    item10 = input("Tenth Item: ")
    item10_price = input("Price: ")
    item10_quantity = input("Quantity: ")

    item1_subtotal = int(item1_price) * int(item1_quantity)
    item2_subtotal = int(item2_price) * int(item2_quantity)
    item3_subtotal = int(item3_price) * int(item3_quantity)
    item4_subtotal = int(item4_price) * int(item4_quantity)
    item5_subtotal = int(item5_price) * int(item5_quantity)
    item6_subtotal = int(item6_price) * int(item6_quantity)
    item7_subtotal = int(item7_price) * int(item7_quantity)
    item8_subtotal = int(item8_price) * int(item8_quantity)
    item9_subtotal = int(item9_price) * int(item9_quantity)
    item10_subtotal = int(item10_price) * int(item10_quantity)

    total = item1_subtotal + item2_subtotal + item3_subtotal + item4_subtotal + item5_subtotal + item6_subtotal + item7_subtotal + item8_subtotal + item9_subtotal + item10_subtotal
    List = {"Name":[item1, item2, item3, item4, item5, item6, item7, item8, item9, item10],
            "Price":[item1_price, item2_price, item3_price, item4_price, item5_price, item6_price, item7_price, item8_price, item9_price, item10_price],
            "Quantity":[item1_quantity, item2_quantity, item3_quantity, item4_quantity, item5_quantity, item6_quantity, item7_quantity, item8_quantity, item9_quantity, item10_quantity],
            "Subtotal":[item1_subtotal, item2_subtotal, item3_subtotal, item4_subtotal, item5_subtotal, item6_subtotal, item7_subtotal, item8_subtotal, item9_subtotal, item10_subtotal]}
    df = pandas.DataFrame(List)
    print("\n")
    print(df)

    Tax = open("tax.txt", "r")
    tax = Tax.read()
    Tax.close()

    final_total = int(total) + int(tax)

    List2 = {"Final Total":final_total, "Tax":tax, "Total":total, "Total Items":10}
    ds = pandas.Series(List2)
    print("\n")
    print(ds)

    File = open("sales/sales.txt", "a")
    File.write("\n" + str(ds))
    File.close

def eleven() :
    item1 = input("First Item: ")
    item1_price = input("Price: ")
    item1_quantity = input("Quantity: ")

    print("\n")

    item2 = input("Second Item: ")
    item2_price = input("Price: ")
    item2_quantity = input("Qunatity: ")

    print("\n")

    item3 = input("Third Item: ")
    item3_price = input("Price: ")
    item3_quantity = input("Quantity: ")

    print("\n")

    item4 = input("Fourth Item: ")
    item4_price = input("Price: ")
    item4_quantity = input("Quantity: ")

    print("\n")

    item5 = input("Fifth Item: ")
    item5_price = input("Price: ")
    item5_quantity = input("Quantity: ")

    print("\n")

    item6 = input("Sixth Item: ")
    item6_price = input("Price: ")
    item6_quantity = input("Quantity: ")

    print("\n")

    item7 = input("Seventh Item: ")
    item7_price = input("Price: ")
    item7_quantity = input("Quantity: ")

    print("\n")

    item8 = input("Eirght Item: ")
    item8_price = input("Price: ")
    item8_quantity = input("Quantity: ")

    print("\n")

    item9 = input("Ninth Item: ")
    item9_price = input("Price: ")
    item9_quantity =  input("Quantity: ")

    print("\n")

    item10 = input("Tenth Item: ")
    item10_price = input("Price: ")
    item10_quantity = input("Quantity: ")

    print("\n")

    item11 = input("Eleventh Item: ")
    item11_price = input("Price: ")
    item11_quantity = input("Quantity: ")

    item1_subtotal = int(item1_price) * int(item1_quantity)
    item2_subtotal = int(item2_price) * int(item2_quantity)
    item3_subtotal = int(item3_price) * int(item3_quantity)
    item4_subtotal = int(item4_price) * int(item4_quantity)
    item5_subtotal = int(item5_price) * int(item5_quantity)
    item6_subtotal = int(item6_price) * int(item6_quantity)
    item7_subtotal = int(item7_price) * int(item7_quantity)
    item8_subtotal = int(item8_price) * int(item8_quantity)
    item9_subtotal = int(item9_price) * int(item9_quantity)
    item10_subtotal = int(item10_price) * int(item10_quantity)
    item11_subtotal = int(item11_price) * int(item11_quantity)

    total = item1_subtotal + item2_subtotal + item3_subtotal + item4_subtotal + item5_subtotal + item6_subtotal + item7_subtotal + item8_subtotal + item9_subtotal + item10_subtotal + item11_subtotal
    List = {"Name":[item1, item2, item3, item4, item5, item6, item7, item8, item9, item10, item11],
            "Price":[item1_price, item2_price, item3_price, item4_price, item5_price, item6_price, item7_price, item8_price, item9_price, item10_price, item11_price],
            "Quantity":[item1_quantity, item2_quantity, item3_quantity, item4_quantity, item5_quantity, item6_quantity, item7_quantity, item8_quantity, item9_quantity, item10_quantity, item11_quantity],
            "Subtotal":[item1_subtotal, item2_subtotal, item3_subtotal, item4_subtotal, item5_subtotal, item6_subtotal, item7_subtotal, item8_subtotal, item9_subtotal, item10_subtotal, item11_subtotal]}
    df = pandas.DataFrame(List)
    print("\n")
    print(df)

    Tax = open("tax.txt", "r")
    tax = Tax.read()
    Tax.close()

    final_total = int(total) + int(tax)

    List2 = {"Final Total":final_total, "Tax":tax, "Total":total, "Total Items":11}
    ds = pandas.Series(List2)
    print("\n")
    print(ds)

    File = open("sales/sales.txt", "a")
    File.write("\n" + str(ds))
    File.close

def tewleve() :
    item1 = input("First Item: ")
    item1_price = input("Price: ")
    item1_quantity = input("Quantity: ")

    print("\n")

    item2 = input("Second Item: ")
    item2_price = input("Price: ")
    item2_quantity = input("Qunatity: ")

    print("\n")

    item3 = input("Third Item: ")
    item3_price = input("Price: ")
    item3_quantity = input("Quantity: ")

    print("\n")

    item4 = input("Fourth Item: ")
    item4_price = input("Price: ")
    item4_quantity = input("Quantity: ")

    print("\n")

    item5 = input("Fifth Item: ")
    item5_price = input("Price: ")
    item5_quantity = input("Quantity: ")

    print("\n")

    item6 = input("Sixth Item: ")
    item6_price = input("Price: ")
    item6_quantity = input("Quantity: ")

    print("\n")

    item7 = input("Seventh Item: ")
    item7_price = input("Price: ")
    item7_quantity = input("Quantity: ")

    print("\n")

    item8 = input("Eirght Item: ")
    item8_price = input("Price: ")
    item8_quantity = input("Quantity: ")

    print("\n")

    item9 = input("Ninth Item: ")
    item9_price = input("Price: ")
    item9_quantity =  input("Quantity: ")

    print("\n")

    item10 = input("Tenth Item: ")
    item10_price = input("Price: ")
    item10_quantity = input("Quantity: ")

    print("\n")

    item11 = input("Eleventh Item: ")
    item11_price = input("Price: ")
    item11_quantity = input("Quantity: ")

    print("\n")

    item12 = input("tewlevth Item: ")
    item12_price = input("Price: ")
    item12_quantity = input("Quantity: ")

    item1_subtotal = int(item1_price) * int(item1_quantity)
    item2_subtotal = int(item2_price) * int(item2_quantity)
    item3_subtotal = int(item3_price) * int(item3_quantity)
    item4_subtotal = int(item4_price) * int(item4_quantity)
    item5_subtotal = int(item5_price) * int(item5_quantity)
    item6_subtotal = int(item6_price) * int(item6_quantity)
    item7_subtotal = int(item7_price) * int(item7_quantity)
    item8_subtotal = int(item8_price) * int(item8_quantity)
    item9_subtotal = int(item9_price) * int(item9_quantity)
    item10_subtotal = int(item10_price) * int(item10_quantity)
    item11_subtotal = int(item11_price) * int(item11_quantity)
    item12_subtotal = int(item12_price) * int(item12_quantity)

    total = item1_subtotal + item2_subtotal + item3_subtotal + item4_subtotal + item5_subtotal + item6_subtotal + item7_subtotal + item8_subtotal + item9_subtotal + item10_subtotal + item11_subtotal + item12_subtotal
    List = {"Name":[item1, item2, item3, item4, item5, item6, item7, item8, item9, item10, item11, item12],
            "Price":[item1_price, item2_price, item3_price, item4_price, item5_price, item6_price, item7_price, item8_price, item9_price, item10_price, item11_price, item12_price],
            "Quantity":[item1_quantity, item2_quantity, item3_quantity, item4_quantity, item5_quantity, item6_quantity, item7_quantity, item8_quantity, item9_quantity, item10_quantity, item11_quantity, item12_quantity],
            "Subtotal":[item1_subtotal, item2_subtotal, item3_subtotal, item4_subtotal, item5_subtotal, item6_subtotal, item7_subtotal, item8_subtotal, item9_subtotal, item10_subtotal, item11_subtotal, item12_subtotal]}
    df = pandas.DataFrame(List)
    print("\n")
    print(df)

    Tax = open("tax.txt", "r")
    tax = Tax.read()
    Tax.close()

    final_total = int(total) + int(tax)

    List2 = {"Final Total":final_total, "Tax":tax, "Total":total, "Total Items":12}
    ds = pandas.Series(List2)
    print("\n")
    print(ds)

    File = open("sales/sales.txt", "a")
    File.write("\n" + str(ds))
    File.close

def thirteen() :
    item1 = input("First Item: ")
    item1_price = input("Price: ")
    item1_quantity = input("Quantity: ")

    print("\n")

    item2 = input("Second Item: ")
    item2_price = input("Price: ")
    item2_quantity = input("Qunatity: ")

    print("\n")

    item3 = input("Third Item: ")
    item3_price = input("Price: ")
    item3_quantity = input("Quantity: ")

    print("\n")

    item4 = input("Fourth Item: ")
    item4_price = input("Price: ")
    item4_quantity = input("Quantity: ")

    print("\n")

    item5 = input("Fifth Item: ")
    item5_price = input("Price: ")
    item5_quantity = input("Quantity: ")

    print("\n")

    item6 = input("Sixth Item: ")
    item6_price = input("Price: ")
    item6_quantity = input("Quantity: ")

    print("\n")

    item7 = input("Seventh Item: ")
    item7_price = input("Price: ")
    item7_quantity = input("Quantity: ")

    print("\n")

    item8 = input("Eirght Item: ")
    item8_price = input("Price: ")
    item8_quantity = input("Quantity: ")

    print("\n")

    item9 = input("Ninth Item: ")
    item9_price = input("Price: ")
    item9_quantity =  input("Quantity: ")

    print("\n")

    item10 = input("Tenth Item: ")
    item10_price = input("Price: ")
    item10_quantity = input("Quantity: ")

    print("\n")

    item11 = input("Eleventh Item: ")
    item11_price = input("Price: ")
    item11_quantity = input("Quantity: ")

    print("\n")

    item12 = input("tewlevth Item: ")
    item12_price = input("Price: ")
    item12_quantity = input("Quantity: ")

    print("\n")

    item13 = input("Thirteenth Item: ")
    item13_price = input("Price: ")
    item13_quantity = input("quantity: ")

    item1_subtotal = int(item1_price) * int(item1_quantity)
    item2_subtotal = int(item2_price) * int(item2_quantity)
    item3_subtotal = int(item3_price) * int(item3_quantity)
    item4_subtotal = int(item4_price) * int(item4_quantity)
    item5_subtotal = int(item5_price) * int(item5_quantity)
    item6_subtotal = int(item6_price) * int(item6_quantity)
    item7_subtotal = int(item7_price) * int(item7_quantity)
    item8_subtotal = int(item8_price) * int(item8_quantity)
    item9_subtotal = int(item9_price) * int(item9_quantity)
    item10_subtotal = int(item10_price) * int(item10_quantity)
    item11_subtotal = int(item11_price) * int(item11_quantity)
    item12_subtotal = int(item12_price) * int(item12_quantity)
    item13_subtotal = int(item13_price) * int(item13_quantity)

    total = item1_subtotal + item2_subtotal + item3_subtotal + item4_subtotal + item5_subtotal + item6_subtotal + item7_subtotal + item8_subtotal + item9_subtotal + item10_subtotal + item11_subtotal + item12_subtotal + item13_subtotal
    List = {"Name":[item1, item2, item3, item4, item5, item6, item7, item8, item9, item10, item11, item12, item13],
            "Price":[item1_price, item2_price, item3_price, item4_price, item5_price, item6_price, item7_price, item8_price, item9_price, item10_price, item11_price, item12_price, item13_price],
            "Quantity":[item1_quantity, item2_quantity, item3_quantity, item4_quantity, item5_quantity, item6_quantity, item7_quantity, item8_quantity, item9_quantity, item10_quantity, item11_quantity, item12_quantity, item13_quantity],
            "Subtotal":[item1_subtotal, item2_subtotal, item3_subtotal, item4_subtotal, item5_subtotal, item6_subtotal, item7_subtotal, item8_subtotal, item9_subtotal, item10_subtotal, item11_subtotal, item12_subtotal, item13_subtotal]}
    df = pandas.DataFrame(List)
    print("\n")
    print(df)

    Tax = open("tax.txt", "r")
    tax = Tax.read()
    Tax.close()

    final_total = int(total) + int(tax)

    List2 = {"Final Total":final_total, "Tax":tax, "Total":total, "Total Items":13}
    ds = pandas.Series(List2)
    print("\n")
    print(ds)

    File = open("sales/sales.txt", "a")
    File.write("\n" + str(ds))
    File.close

def fourteen() :
    item1 = input("First Item: ")
    item1_price = input("Price: ")
    item1_quantity = input("Quantity: ")

    print("\n")

    item2 = input("Second Item: ")
    item2_price = input("Price: ")
    item2_quantity = input("Qunatity: ")

    print("\n")

    item3 = input("Third Item: ")
    item3_price = input("Price: ")
    item3_quantity = input("Quantity: ")

    print("\n")

    item4 = input("Fourth Item: ")
    item4_price = input("Price: ")
    item4_quantity = input("Quantity: ")

    print("\n")

    item5 = input("Fifth Item: ")
    item5_price = input("Price: ")
    item5_quantity = input("Quantity: ")

    print("\n")

    item6 = input("Sixth Item: ")
    item6_price = input("Price: ")
    item6_quantity = input("Quantity: ")

    print("\n")

    item7 = input("Seventh Item: ")
    item7_price = input("Price: ")
    item7_quantity = input("Quantity: ")

    print("\n")

    item8 = input("Eirght Item: ")
    item8_price = input("Price: ")
    item8_quantity = input("Quantity: ")

    print("\n")

    item9 = input("Ninth Item: ")
    item9_price = input("Price: ")
    item9_quantity =  input("Quantity: ")

    print("\n")

    item10 = input("Tenth Item: ")
    item10_price = input("Price: ")
    item10_quantity = input("Quantity: ")

    print("\n")

    item11 = input("Eleventh Item: ")
    item11_price = input("Price: ")
    item11_quantity = input("Quantity: ")

    print("\n")

    item12 = input("tewlevth Item: ")
    item12_price = input("Price: ")
    item12_quantity = input("Quantity: ")

    print("\n")

    item13 = input("Thirteenth Item: ")
    item13_price = input("Price: ")
    item13_quantity = input("quantity: ")

    print("\n")

    item14 = input("Fourteenth Item: ")
    item14_price = input("Price: ")
    item14_quantity = input("quantity: ")

    item1_subtotal = int(item1_price) * int(item1_quantity)
    item2_subtotal = int(item2_price) * int(item2_quantity)
    item3_subtotal = int(item3_price) * int(item3_quantity)
    item4_subtotal = int(item4_price) * int(item4_quantity)
    item5_subtotal = int(item5_price) * int(item5_quantity)
    item6_subtotal = int(item6_price) * int(item6_quantity)
    item7_subtotal = int(item7_price) * int(item7_quantity)
    item8_subtotal = int(item8_price) * int(item8_quantity)
    item9_subtotal = int(item9_price) * int(item9_quantity)
    item10_subtotal = int(item10_price) * int(item10_quantity)
    item11_subtotal = int(item11_price) * int(item11_quantity)
    item12_subtotal = int(item12_price) * int(item12_quantity)
    item13_subtotal = int(item13_price) * int(item13_quantity)
    item14_subtotal = int(item14_price) * int(item14_quantity)

    total = item1_subtotal + item2_subtotal + item3_subtotal + item4_subtotal + item5_subtotal + item6_subtotal + item7_subtotal + item8_subtotal + item9_subtotal + item10_subtotal + item11_subtotal + item12_subtotal + item13_subtotal, item14_subtotal
    List = {"Name":[item1, item2, item3, item4, item5, item6, item7, item8, item9, item10, item11, item12, item13, item14],
            "Price":[item1_price, item2_price, item3_price, item4_price, item5_price, item6_price, item7_price, item8_price, item9_price, item10_price, item11_price, item12_price, item13_price, item14_price],
            "Quantity":[item1_quantity, item2_quantity, item3_quantity, item4_quantity, item5_quantity, item6_quantity, item7_quantity, item8_quantity, item9_quantity, item10_quantity, item11_quantity, item12_quantity, item13_quantity, item14_quantity],
            "Subtotal":[item1_subtotal, item2_subtotal, item3_subtotal, item4_subtotal, item5_subtotal, item6_subtotal, item7_subtotal, item8_subtotal, item9_subtotal, item10_subtotal, item11_subtotal, item12_subtotal, item13_subtotal, item14_subtotal]}
    df = pandas.DataFrame(List)
    print("\n")
    print(df)

    Tax = open("tax.txt", "r")
    tax = Tax.read()
    Tax.close()

    final_total = int(total) + int(tax)

    List2 = {"Final Total":final_total, "Tax":tax, "Total":total, "Total Items":14}
    ds = pandas.Series(List2)
    print("\n")
    print(ds)

    File = open("sales/sales.txt", "a")
    File.write("\n" + str(ds))
    File.close

def fifteen() :
    item1 = input("First Item: ")
    item1_price = input("Price: ")
    item1_quantity = input("Quantity: ")

    print("\n")

    item2 = input("Second Item: ")
    item2_price = input("Price: ")
    item2_quantity = input("Qunatity: ")

    print("\n")

    item3 = input("Third Item: ")
    item3_price = input("Price: ")
    item3_quantity = input("Quantity: ")

    print("\n")

    item4 = input("Fourth Item: ")
    item4_price = input("Price: ")
    item4_quantity = input("Quantity: ")

    print("\n")

    item5 = input("Fifth Item: ")
    item5_price = input("Price: ")
    item5_quantity = input("Quantity: ")

    print("\n")

    item6 = input("Sixth Item: ")
    item6_price = input("Price: ")
    item6_quantity = input("Quantity: ")

    print("\n")

    item7 = input("Seventh Item: ")
    item7_price = input("Price: ")
    item7_quantity = input("Quantity: ")

    print("\n")

    item8 = input("Eirght Item: ")
    item8_price = input("Price: ")
    item8_quantity = input("Quantity: ")

    print("\n")

    item9 = input("Ninth Item: ")
    item9_price = input("Price: ")
    item9_quantity =  input("Quantity: ")

    print("\n")

    item10 = input("Tenth Item: ")
    item10_price = input("Price: ")
    item10_quantity = input("Quantity: ")

    print("\n")

    item11 = input("Eleventh Item: ")
    item11_price = input("Price: ")
    item11_quantity = input("Quantity: ")

    print("\n")

    item12 = input("tewlevth Item: ")
    item12_price = input("Price: ")
    item12_quantity = input("Quantity: ")

    print("\n")

    item13 = input("Thirteenth Item: ")
    item13_price = input("Price: ")
    item13_quantity = input("quantity: ")

    print("\n")

    item14 = input("Fourteenth Item: ")
    item14_price = input("Price: ")
    item14_quantity = input("Quantity: ")

    print("\n")

    item15 = input("Fifteenth Item: ")
    item15_price = input("Price:")
    item15_quantity = input("Quantity: ")

    item1_subtotal = int(item1_price) * int(item1_quantity)
    item2_subtotal = int(item2_price) * int(item2_quantity)
    item3_subtotal = int(item3_price) * int(item3_quantity)
    item4_subtotal = int(item4_price) * int(item4_quantity)
    item5_subtotal = int(item5_price) * int(item5_quantity)
    item6_subtotal = int(item6_price) * int(item6_quantity)
    item7_subtotal = int(item7_price) * int(item7_quantity)
    item8_subtotal = int(item8_price) * int(item8_quantity)
    item9_subtotal = int(item9_price) * int(item9_quantity)
    item10_subtotal = int(item10_price) * int(item10_quantity)
    item11_subtotal = int(item11_price) * int(item11_quantity)
    item12_subtotal = int(item12_price) * int(item12_quantity)
    item13_subtotal = int(item13_price) * int(item13_quantity)
    item14_subtotal = int(item14_price) * int(item14_quantity)
    item15_subtotal = int(item15_price) * int(item15_quantity)

    total = item1_subtotal + item2_subtotal + item3_subtotal + item4_subtotal + item5_subtotal + item6_subtotal + item7_subtotal + item8_subtotal + item9_subtotal + item10_subtotal + item11_subtotal + item12_subtotal + item13_subtotal + item14_subtotal + item15_subtotal
    List = {"Name":[item1, item2, item3, item4, item5, item6, item7, item8, item9, item10, item11, item12, item13, item14, item15],
            "Price":[item1_price, item2_price, item3_price, item4_price, item5_price, item6_price, item7_price, item8_price, item9_price, item10_price, item11_price, item12_price, item13_price, item14_price, item15_price],
            "Quantity":[item1_quantity, item2_quantity, item3_quantity, item4_quantity, item5_quantity, item6_quantity, item7_quantity, item8_quantity, item9_quantity, item10_quantity, item11_quantity, item12_quantity, item13_quantity, item14_quantity, item15_quantity],
            "Subtotal":[item1_subtotal, item2_subtotal, item3_subtotal, item4_subtotal, item5_subtotal, item6_subtotal, item7_subtotal, item8_subtotal, item9_subtotal, item10_subtotal, item11_subtotal, item12_subtotal, item13_subtotal, item14_subtotal, item15_subtotal]}
    df = pandas.DataFrame(List)
    print("\n")
    print(df)

    Tax = open("tax.txt", "r")
    tax = Tax.read()
    Tax.close()

    final_total = int(total) + int(tax)

    List2 = {"Final Total":final_total, "Tax":tax, "Total":total, "Total Items":15}
    ds = pandas.Series(List2)
    print("\n")
    print(ds)

    File = open("sales/sales.txt", "a")
    File.write("\n" + str(ds))
    File.close

def sixteen() :
    item1 = input("First Item: ")
    item1_price = input("Price: ")
    item1_quantity = input("Quantity: ")

    print("\n")

    item2 = input("Second Item: ")
    item2_price = input("Price: ")
    item2_quantity = input("Qunatity: ")

    print("\n")

    item3 = input("Third Item: ")
    item3_price = input("Price: ")
    item3_quantity = input("Quantity: ")

    print("\n")

    item4 = input("Fourth Item: ")
    item4_price = input("Price: ")
    item4_quantity = input("Quantity: ")

    print("\n")

    item5 = input("Fifth Item: ")
    item5_price = input("Price: ")
    item5_quantity = input("Quantity: ")

    print("\n")

    item6 = input("Sixth Item: ")
    item6_price = input("Price: ")
    item6_quantity = input("Quantity: ")

    print("\n")

    item7 = input("Seventh Item: ")
    item7_price = input("Price: ")
    item7_quantity = input("Quantity: ")

    print("\n")

    item8 = input("Eirght Item: ")
    item8_price = input("Price: ")
    item8_quantity = input("Quantity: ")

    print("\n")

    item9 = input("Ninth Item: ")
    item9_price = input("Price: ")
    item9_quantity =  input("Quantity: ")

    print("\n")

    item10 = input("Tenth Item: ")
    item10_price = input("Price: ")
    item10_quantity = input("Quantity: ")

    print("\n")

    item11 = input("Eleventh Item: ")
    item11_price = input("Price: ")
    item11_quantity = input("Quantity: ")

    print("\n")

    item12 = input("tewlevth Item: ")
    item12_price = input("Price: ")
    item12_quantity = input("Quantity: ")

    print("\n")

    item13 = input("Thirteenth Item: ")
    item13_price = input("Price: ")
    item13_quantity = input("quantity: ")

    print("\n")

    item14 = input("Fourteenth Item: ")
    item14_price = input("Price: ")
    item14_quantity = input("Quantity: ")

    print("\n")

    item15 = input("Fifteenth Item: ")
    item15_price = input("Price:")
    item15_quantity = input("Quantity: ")

    print("\n")

    item16 = input("Sixteenth Item: ")
    item16_price = input("Price: ")
    item16_quantity = input("Quantity: ")

    item1_subtotal = int(item1_price) * int(item1_quantity)
    item2_subtotal = int(item2_price) * int(item2_quantity)
    item3_subtotal = int(item3_price) * int(item3_quantity)
    item4_subtotal = int(item4_price) * int(item4_quantity)
    item5_subtotal = int(item5_price) * int(item5_quantity)
    item6_subtotal = int(item6_price) * int(item6_quantity)
    item7_subtotal = int(item7_price) * int(item7_quantity)
    item8_subtotal = int(item8_price) * int(item8_quantity)
    item9_subtotal = int(item9_price) * int(item9_quantity)
    item10_subtotal = int(item10_price) * int(item10_quantity)
    item11_subtotal = int(item11_price) * int(item11_quantity)
    item12_subtotal = int(item12_price) * int(item12_quantity)
    item13_subtotal = int(item13_price) * int(item13_quantity)
    item14_subtotal = int(item14_price) * int(item14_quantity)
    item15_subtotal = int(item15_price) * int(item15_quantity)
    item16_subtotal = int(item16_price) * int(item16_quantity)

    total = item1_subtotal + item2_subtotal + item3_subtotal + item4_subtotal + item5_subtotal + item6_subtotal + item7_subtotal + item8_subtotal + item9_subtotal + item10_subtotal + item11_subtotal + item12_subtotal + item13_subtotal + item14_subtotal + item15_subtotal + item16_subtotal
    List = {"Name":[item1, item2, item3, item4, item5, item6, item7, item8, item9, item10, item11, item12, item13, item14, item15, item16],
            "Price":[item1_price, item2_price, item3_price, item4_price, item5_price, item6_price, item7_price, item8_price, item9_price, item10_price, item11_price, item12_price, item13_price, item14_price, item15_price, item16_price],
            "Quantity":[item1_quantity, item2_quantity, item3_quantity, item4_quantity, item5_quantity, item6_quantity, item7_quantity, item8_quantity, item9_quantity, item10_quantity, item11_quantity, item12_quantity, item13_quantity, item14_quantity, item15_quantity, item16_quantity],
            "Subtotal":[item1_subtotal, item2_subtotal, item3_subtotal, item4_subtotal, item5_subtotal, item6_subtotal, item7_subtotal, item8_subtotal, item9_subtotal, item10_subtotal, item11_subtotal, item12_subtotal, item13_subtotal, item14_subtotal, item15_subtotal, item16_subtotal]}
    df = pandas.DataFrame(List)
    print("\n")
    print(df)

    Tax = open("tax.txt", "r")
    tax = Tax.read()
    Tax.close()

    final_total = int(total) + int(tax)

    List2 = {"Final Total":final_total, "Tax":tax, "Total":total, "Total Items":16}
    ds = pandas.Series(List2)
    print("\n")
    print(ds)

    File = open("sales/sales.txt", "a")
    File.write("\n" + str(ds))
    File.close

def seventeen() :
    item1 = input("First Item: ")
    item1_price = input("Price: ")
    item1_quantity = input("Quantity: ")

    print("\n")

    item2 = input("Second Item: ")
    item2_price = input("Price: ")
    item2_quantity = input("Qunatity: ")

    print("\n")

    item3 = input("Third Item: ")
    item3_price = input("Price: ")
    item3_quantity = input("Quantity: ")

    print("\n")

    item4 = input("Fourth Item: ")
    item4_price = input("Price: ")
    item4_quantity = input("Quantity: ")

    print("\n")

    item5 = input("Fifth Item: ")
    item5_price = input("Price: ")
    item5_quantity = input("Quantity: ")

    print("\n")

    item6 = input("Sixth Item: ")
    item6_price = input("Price: ")
    item6_quantity = input("Quantity: ")

    print("\n")

    item7 = input("Seventh Item: ")
    item7_price = input("Price: ")
    item7_quantity = input("Quantity: ")

    print("\n")

    item8 = input("Eirght Item: ")
    item8_price = input("Price: ")
    item8_quantity = input("Quantity: ")

    print("\n")

    item9 = input("Ninth Item: ")
    item9_price = input("Price: ")
    item9_quantity =  input("Quantity: ")

    print("\n")

    item10 = input("Tenth Item: ")
    item10_price = input("Price: ")
    item10_quantity = input("Quantity: ")

    print("\n")

    item11 = input("Eleventh Item: ")
    item11_price = input("Price: ")
    item11_quantity = input("Quantity: ")

    print("\n")

    item12 = input("tewlevth Item: ")
    item12_price = input("Price: ")
    item12_quantity = input("Quantity: ")

    print("\n")

    item13 = input("Thirteenth Item: ")
    item13_price = input("Price: ")
    item13_quantity = input("quantity: ")

    print("\n")

    item14 = input("Fourteenth Item: ")
    item14_price = input("Price: ")
    item14_quantity = input("Quantity: ")

    print("\n")

    item15 = input("Fifteenth Item: ")
    item15_price = input("Price:")
    item15_quantity = input("Quantity: ")

    print("\n")

    item16 = input("Sixteenth Item: ")
    item16_price = input("Price: ")
    item16_quantity = input("Quantity: ")

    print("\n")

    item17 = input("seventeenth Item: ")
    item17_price = input("Price: ")
    item17_quantity = input("Quantity: ")

    item1_subtotal = int(item1_price) * int(item1_quantity)
    item2_subtotal = int(item2_price) * int(item2_quantity)
    item3_subtotal = int(item3_price) * int(item3_quantity)
    item4_subtotal = int(item4_price) * int(item4_quantity)
    item5_subtotal = int(item5_price) * int(item5_quantity)
    item6_subtotal = int(item6_price) * int(item6_quantity)
    item7_subtotal = int(item7_price) * int(item7_quantity)
    item8_subtotal = int(item8_price) * int(item8_quantity)
    item9_subtotal = int(item9_price) * int(item9_quantity)
    item10_subtotal = int(item10_price) * int(item10_quantity)
    item11_subtotal = int(item11_price) * int(item11_quantity)
    item12_subtotal = int(item12_price) * int(item12_quantity)
    item13_subtotal = int(item13_price) * int(item13_quantity)
    item14_subtotal = int(item14_price) * int(item14_quantity)
    item15_subtotal = int(item15_price) * int(item15_quantity)
    item16_subtotal = int(item16_price) * int(item16_quantity)
    item17_subtotal = int(item17_price) * int(item17_quantity)

    total = item1_subtotal + item2_subtotal + item3_subtotal + item4_subtotal + item5_subtotal + item6_subtotal + item7_subtotal + item8_subtotal + item9_subtotal + item10_subtotal + item11_subtotal + item12_subtotal + item13_subtotal + item14_subtotal + item15_subtotal + item16_subtotal + item17_subtotal
    List = {"Name":[item1, item2, item3, item4, item5, item6, item7, item8, item9, item10, item11, item12, item13, item14, item15, item16, item17],
            "Price":[item1_price, item2_price, item3_price, item4_price, item5_price, item6_price, item7_price, item8_price, item9_price, item10_price, item11_price, item12_price, item13_price, item14_price, item15_price, item16_price, item17_price],
            "Quantity":[item1_quantity, item2_quantity, item3_quantity, item4_quantity, item5_quantity, item6_quantity, item7_quantity, item8_quantity, item9_quantity, item10_quantity, item11_quantity, item12_quantity, item13_quantity, item14_quantity, item15_quantity, item16_quantity, item17_quantity],
            "Subtotal":[item1_subtotal, item2_subtotal, item3_subtotal, item4_subtotal, item5_subtotal, item6_subtotal, item7_subtotal, item8_subtotal, item9_subtotal, item10_subtotal, item11_subtotal, item12_subtotal, item13_subtotal, item14_subtotal, item15_subtotal, item16_subtotal, item17_subtotal]}
    df = pandas.DataFrame(List)
    print("\n")
    print(df)

    Tax = open("tax.txt", "r")
    tax = Tax.read()
    Tax.close()

    final_total = int(total) + int(tax)

    List2 = {"Final Total":final_total, "Tax":tax, "Total":total, "Total Items":17}
    ds = pandas.Series(List2)
    print("\n")
    print(ds)

    File = open("sales/sales.txt", "a")
    File.write("\n" + str(ds))
    File.close

def edit() :
    new_name = input("New Company name: ")
    company_file = open("Company.txt", "w")
    company_file.write(new_name)
    company_file.close()

    new_tax = int(input("New Tax: "))
    tax_file = open("tax.txt", "w")
    tax_file.write(str(new_tax))
    tax_file.close()

    new_others = input("New other's line: ")
    others_file = open("others.txt", "w")
    others_file.write(new_others)
    others_file.close()

print("\n---BILL PRINT---\n")

#while True :
#   Company_file = open("Company.txt", "r")
#   Company_name = Company_file.read()
#   Company_file.close()
#
#    name = input("Customer Name: ")
#
#   if name == "none" :
#       break
#
#   elif name == "$edit" :
#       edit()
#
#   else:
#       items = int(input("Items Bought: "))


def args() :
    args = ArgumentParser()
    args.add_argument("Number_of_items")
    return args.parse_args()

if __name__ == "__main__" :
    arguments = args()
    Number_of_Items = int(arguments.Number_of_items)

    Company_file = open("Company.txt", "r")
    Company_name = Company_file.read()
    Company_file.close()

    if Number_of_Items == 1 :
        one()
        print("\tThank you for shopping at " + Company_name + "\n")

    elif Number_of_Items == 2 :
        two()
        print("\tThank you for shopping at " + Company_name + "\n")

    elif Number_of_Items == 3 :
        three()
        print("\tThank you for shopping at " + Company_name + "\n")

    elif Number_of_Items == 4 :
        four()
        print("\tThank you for shopping at " + Company_name + "\n")

    elif Number_of_Items == 5 :
        five()
        print("\tThank you for shopping at " + Company_name + "\n")

    elif Number_of_Items == 6 :
        six()
        print("\tThank you for shopping at " + Company_name + "\n")

    elif Number_of_Items == 7 :
        seven()
        print("\tThank you for shopping at " + Company_name + "\n")

    elif Number_of_Items == 8 :
        eight()
        print("\tThank you for shopping at " + Company_name + "\n")

    elif Number_of_Items == 9 :
        nine()
        print("\tThank you for shopping at " + Company_name + "\n")

    elif Number_of_Items == 10 :
        ten()
        print("\tThank you for shopping at " + Company_name + "\n")

    elif Number_of_Items == 11 :
        eleven()
        print("\tThank you for shopping at " + Company_name + "\n")

    elif Number_of_Items == 12 :
        tewleve()
        print("\tThank you for shopping at " + Company_name + "\n")

    elif Number_of_Items == 13 :
        thirteen()
        print("\tThank you for shopping at " + Company_name + "\n")

    elif Number_of_Items == 14 :
        fourteen()
        print("\tThank you for shopping at " + Company_name + "\n")

    elif Number_of_Items == 15 :
        fifteen()
        print("\tThank you for shopping at " + Company_name + "\n")

    elif Number_of_Items == 16 :
        sixteen()
        print("\tThank you for shopping at " + Company_name + "\n")

    else :
        print("Not Yet Available")
