echo "Installing dependencies..."
sudo apt-get install python3-pip
pip3 install pandas
echo "Dependencies installed"
